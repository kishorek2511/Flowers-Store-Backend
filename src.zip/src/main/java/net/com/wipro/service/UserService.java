package net.com.wipro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.com.wipro.model.User;
import net.com.wipro.repository.UserRepository;

@Service
@Transactional
public class UserService {

	@Autowired
	private UserRepository repo;
	
	public List<User> listAll() {
		
		return repo.findAll();
	}
	
	public User saveUser(User user) {
		return repo.save(user);
	}
	
	public User fetchUserEmaiId(String email) {
	    return repo.findByEmailId(email);
	}
	
	public User fetchUserByEmaiIdAndPassword(String email, String  password) {
	    return repo.findByEmailIdAndPassword(email, password);
	}

}
