package net.com.wipro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.com.wipro.model.Category;
import net.com.wipro.model.Products;
import net.com.wipro.model.Size;
import net.com.wipro.repository.ProductRepository;
import net.com.wipro.repository.SizeRepository;


@Service
public class SizeService {

	@Autowired
	SizeRepository SizeRepo;
	ProductRepository productRepo;
	
	public List<Size> getAllSizes(){
		return SizeRepo.findAll();
	}

	
     public List<Size> getSizeByProductId(Products products){
		
		return SizeRepo.findByProductId(products.getProductid());
		
	}
	
	
	public List<Size> getProductBySizeId(Size size){
		return SizeRepo.findByProductId(size.getSizeid());
	}
	
}
