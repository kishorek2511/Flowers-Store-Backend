package net.com.wipro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.com.wipro.model.Category;
import net.com.wipro.model.Products;
import net.com.wipro.repository.CategoryRepository;
import net.com.wipro.repository.ProductRepository;

@Service
public class CategoryService {
	@Autowired
	CategoryRepository categoryRepo;
	public List<Category>getAllCategories(){
	return categoryRepo.findAll();	
	}
	
}
