package net.com.wipro.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import net.com.wipro.model.Orde;
import net.com.wipro.repository.OrdeRepository;

 
 
@Component
@Service
public class OrdeService {
	@Autowired
	
	 private JavaMailSender javaMailSender;

	    public Orde sendEmail(Orde email) throws MailException {
	        SimpleMailMessage mail = new SimpleMailMessage();

	        mail.setTo(email.getEmail());
	        mail.setSubject("Order Confirmation");
	        mail.setText("Thank You, Your order is being processed");
	        
	        javaMailSender.send(mail);
	        
	        return ordeRepo.save(email);
	    }
	    @Autowired
	    OrdeRepository ordeRepo;
	   public Orde addDetails(Orde details) {
			return ordeRepo.save(details);
		}
	   
	   public List<Orde>getAllOrders(){
			return ordeRepo.findAll();	
			}
}
