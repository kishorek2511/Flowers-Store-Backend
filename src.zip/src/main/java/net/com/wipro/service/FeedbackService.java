package net.com.wipro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import net.com.wipro.model.Feedback;

import net.com.wipro.repository.FeedbackRepository;


@Component
@Service
public class FeedbackService {
	@Autowired
	
	
	 private JavaMailSender javaMailSender;


	    public Feedback sendEmail(Feedback email) throws MailException {
	        SimpleMailMessage mail = new SimpleMailMessage();

	        mail.setTo(email.getEmail());
	        mail.setSubject("Review");
	        mail.setText(email.getMessage());
	        
	        
	        javaMailSender.send(mail);
	        
	        return FeedbackRepo.save(email);
	    }
	    @Autowired
	    FeedbackRepository FeedbackRepo;
	    public Feedback addDetails(Feedback details) {
			return FeedbackRepo.save(details);
		}
	   
	   public List<Feedback>getAllFeedbackrs(){
			return FeedbackRepo.findAll();	
			}
}
