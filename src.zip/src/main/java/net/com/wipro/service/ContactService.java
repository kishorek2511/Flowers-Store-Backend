package net.com.wipro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import net.com.wipro.model.Contact;
import net.com.wipro.repository.ContactRepository;

@Component
@Service
public class ContactService {
	@Autowired
	
	 private JavaMailSender javaMailSender;

	  

	    public Contact sendEmail(Contact email) throws MailException {
	        SimpleMailMessage mail = new SimpleMailMessage();

	        mail.setTo(email.getEmail());
	        mail.setSubject(email.getName());
	        mail.setText(email.getMessage());
	        
	        javaMailSender.send(mail);
	        
	        return ContactRepo.save(email);
	    }
	    @Autowired
	    ContactRepository ContactRepo;
	   public Contact addDetails(Contact details) {
			return ContactRepo.save(details);
		}
	   
	   public List<Contact>getAllContactrs(){
			return ContactRepo.findAll();	
			}
}
