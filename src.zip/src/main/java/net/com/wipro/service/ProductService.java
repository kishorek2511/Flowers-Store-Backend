package net.com.wipro.service;

import org.springframework.stereotype.Service;

import net.com.wipro.model.Category;
import net.com.wipro.model.Products;
import net.com.wipro.model.Size;
import net.com.wipro.repository.ProductRepository;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;

@Service
public class ProductService {

	@Autowired
	ProductRepository productRepo;
	public List<Products>getAllProducts(){
	return productRepo.findAll();	
	}
	
	public List<Products> getByCategoryId(Category category){
		
			return productRepo.findByCategoryId(category.getId());
		
		
	}
	
	public Products saveProduct(Products product) {
		return productRepo.save(product);
	}
	
	public Optional<Products> findByProductId(long id){
		return productRepo.findById(id);
	}
	
	
	
	public List<Products> listAll(String name) {
		
		return productRepo.findProductByName(name);
		
	}
	
	public Products updateProduct(Products product) {
		Optional <Products> products= this.productRepo.findById(product.getId());
		if(products.isPresent()) {
			Products productUpdate = products.get();
			productUpdate.setImageUrl(product.getImageUrl());
			productUpdate.setName(product.getName());
			productUpdate.setUnitPrice(product.getUnitPrice());
			productUpdate.setDescription(product.getDescription());
			productUpdate.setSize(product.getSize());
			productUpdate.setInventory(product.getInventory());
			System.out.println(product.getUnitPrice());
			System.out.println(productUpdate.getUnitPrice());
			
			return productRepo.save(productUpdate);
		}
		else {
			throw new ResourceNotFoundException("Resource not found");
		}
	}
	
	public void deleteProduct(long id) {
	  
	  productRepo.deleteById(id);
	}
	
}
