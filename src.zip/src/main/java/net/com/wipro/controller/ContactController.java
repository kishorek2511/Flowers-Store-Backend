package net.com.wipro.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.com.wipro.model.Contact;
import net.com.wipro.model.Orde;
import net.com.wipro.service.ContactService;
import net.com.wipro.service.OrdeService;

@RestController
@CrossOrigin( origins = "http://localhost:4200")
@RequestMapping(value="/Contact")
public class ContactController {
	@Autowired
	  private ContactService contactService;

	 

	  @RequestMapping(value = "/sendEmail")
	  public ResponseEntity<Contact> sentEmail(@RequestBody Contact email){
	   
		try {
	      contactService.sendEmail(email);
	      return new ResponseEntity<>(email,  HttpStatus.OK);
	      
		}
		catch(MailException e) {
			 return new ResponseEntity<>(null,  HttpStatus.INTERNAL_SERVER_ERROR);
		}
	  }
}
