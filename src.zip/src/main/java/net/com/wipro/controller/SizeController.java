package net.com.wipro.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.com.wipro.model.Category;
import net.com.wipro.model.Products;
import net.com.wipro.model.Size;
import net.com.wipro.service.SizeService;

@RestController
@CrossOrigin( origins = "http://localhost:4200")
@RequestMapping("/size")
public class SizeController {

	@Autowired
	SizeService sizesevice;
	@RequestMapping("getAll")
	public List<Size> getProducts(){
	 return sizesevice.getAllSizes();	
	}
	
	@RequestMapping(value="/getAll/product/{sizeid}")
	public List<Size> getProductBySizeId(Size size){
		return sizesevice.getProductBySizeId(size);
	}
}
