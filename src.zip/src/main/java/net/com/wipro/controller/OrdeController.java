package net.com.wipro.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.com.wipro.model.Orde;
import net.com.wipro.service.OrdeService;


@RestController
@CrossOrigin( origins = "http://localhost:4200")
@RequestMapping(value="/order")
public class OrdeController {
	@Autowired
	  private OrdeService ordeService;

	 

	  @RequestMapping(value = "/sendEmail")
	  public ResponseEntity<Orde> sentEmail(@RequestBody Orde email){
	   
		try {
	      ordeService.sendEmail(email);
	      return new ResponseEntity<>(email,  HttpStatus.OK);
	      
		}
		catch(MailException e) {
			 return new ResponseEntity<>(null,  HttpStatus.INTERNAL_SERVER_ERROR);
		}
	  }
	  
	 @PostMapping(value="/adddetails")
	  public Orde addDetails(@RequestBody Orde details) {
		  ordeService.addDetails(details);
		
		  return details;
	  } 
	 
	 @RequestMapping("getOrders")
		public List<Orde> getOrders(){
		 return ordeService.getAllOrders();	
		}
}

