package net.com.wipro.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.com.wipro.model.Feedback;
import net.com.wipro.service.FeedbackService;

@RestController
@CrossOrigin( origins = "http://localhost:4200")
@RequestMapping(value="/Feedback")
public class FeedbackController {
	@Autowired
	  private FeedbackService FeedbackService;

	 

	  @RequestMapping(value = "/sendEmail")
	  public ResponseEntity<Feedback> sentEmail(@RequestBody Feedback email){
	   
		try {
	      FeedbackService.sendEmail(email);
	      return new ResponseEntity<>(email,  HttpStatus.OK);
	      
		}
		catch(MailException e) {
			 return new ResponseEntity<>(null,  HttpStatus.INTERNAL_SERVER_ERROR);
		}
	  }
}
