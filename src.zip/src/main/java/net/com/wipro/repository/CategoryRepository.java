package net.com.wipro.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.com.wipro.model.Category;

public interface CategoryRepository extends JpaRepository<Category, Long>{

}
