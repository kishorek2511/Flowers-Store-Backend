package net.com.wipro.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import net.com.wipro.model.Orde;


public interface OrdeRepository extends JpaRepository<Orde, Long>{

}