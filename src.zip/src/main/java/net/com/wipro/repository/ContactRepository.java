package net.com.wipro.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.com.wipro.model.Contact;


public interface ContactRepository extends JpaRepository<Contact, Long> {

}
