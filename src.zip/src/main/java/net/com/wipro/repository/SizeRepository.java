package net.com.wipro.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import net.com.wipro.model.Products;
import net.com.wipro.model.Size;

public interface SizeRepository extends JpaRepository<Size, Long>{

	 public List<Size> findByProductId(long id);

}
