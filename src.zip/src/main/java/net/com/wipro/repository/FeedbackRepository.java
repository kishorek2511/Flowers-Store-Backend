package net.com.wipro.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.com.wipro.model.Feedback;

public interface FeedbackRepository extends JpaRepository<Feedback, Long> {

}
