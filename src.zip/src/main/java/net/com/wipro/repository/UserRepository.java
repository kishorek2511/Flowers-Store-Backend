package net.com.wipro.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QuerydslPredicateExecutor;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import net.com.wipro.model.User;

public interface UserRepository extends JpaRepository<User, Long>{

	public User findByEmailId(String emailId);
	public User findByEmailIdAndPassword(String emailId, String password);
	
}
