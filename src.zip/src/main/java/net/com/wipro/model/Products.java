package net.com.wipro.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Products {

 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
  long id;
 
String name,description,unitPrice,imageUrl,size;
private String date;
private int inventory;
private long productid;


 public String getSize() {
	return size;
}
public void setSize(String size) {
	this.size = size;
}
public int getInventory() {
	return inventory;
}
public void setInventory(int inventory) {
	this.inventory = inventory;
}
@ManyToOne(cascade=CascadeType.PERSIST) 
 @JoinColumn(name="categoryId")
 private Category category;

 

public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public Category getCategory() {
	return category;
}
public void setCategory(Category category) {
	this.category = category;
}

public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public String getUnitPrice() {
	return unitPrice;
}
public void setUnitPrice(String unitPrice) {
	this.unitPrice = unitPrice;
}
public String getImageUrl() {
	return imageUrl;
}
public void setImageUrl(String imageUrl) {
	this.imageUrl = imageUrl;
}


public long getProductid() {
	return productid;
}
public void setProductid(long productid) {
	this.productid = productid;
}

}
