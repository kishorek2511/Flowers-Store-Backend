package net.com.wipro.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;

@Entity
public class Orde {
	 @Id
	 @GeneratedValue(strategy=GenerationType.IDENTITY)
	    private long id;
		private String email;
	    private String subject;
	    private String message;
	    private String street;
	    private String city;
	    private String state;
	    private String country;
	    private String paymentType;
	    
	    public long getId() {
			return id;
		}


		public void setId(long id) {
			this.id = id;
		}
	    public String getStreet() {
			return street;
		}


		public void setStreet(String street) {
			this.street = street;
		}


		public String getCity() {
			return city;
		}


		public void setCity(String city) {
			this.city = city;
		}


		public String getState() {
			return state;
		}


		public void setState(String state) {
			this.state = state;
		}


		public String getCountry() {
			return country;
		}


		public void setCountry(String country) {
			this.country = country;
		}


		public String getPaymentType() {
			return paymentType;
		}


		public void setPaymentType(String paymentType) {
			this.paymentType = paymentType;
		}


		public Orde() {
		
		}
		public Orde(Long id,String email,String street,String city, String state,String country,String paymentType) {
			this.id = id;
			this.email = email;
			
			this.street = street;
			this.city = city;
			this.state = state;
			this.country=country;
			this.paymentType=paymentType;
	    }
	    
		
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getSubject() {
			return subject;
		}
		public void setSubject(String subject) {
			this.subject = subject;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
	    
	    
}
