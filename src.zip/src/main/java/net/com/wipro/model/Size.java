package net.com.wipro.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;

@Entity
public class Size {
	@Id
	 @GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	 private long sizeid;
	 private String name;
	 @ManyToOne(cascade=CascadeType.ALL) 
	 @JoinColumn(name="productid")
	 Products product;
	 private long inventory;
	 
	 public Size() {
		 
	 }

	

	public long getId() {
		return id;
	}



	public void setId(long id) {
		this.id = id;
	}



	public long getSizeid() {
		return sizeid;
	}



	public void setSizeid(long sizeid) {
		this.sizeid = sizeid;
	}




	public Products getProduct() {
		return product;
	}



	public void setProduct(Products product) {
		this.product = product;
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}



	public long getInventory() {
		return inventory;
	}



	public void setInventory(long inventory) {
		this.inventory = inventory;
	}
	 
	
}
