package net.com.wipro.controller;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.com.wipro.model.Products;
import net.com.wipro.repository.ProductRepository;
import net.com.wipro.service.ProductService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = ProductService.class, secure = false)
@WebAppConfiguration
public class ProductServiceTest {

	@Autowired
	private ProductService productService;
	
	@MockBean
	private ProductRepository productRepository;
	
	 @Test
	//@Ignore
	public void testAddProduct(){

		Products product = new Products();
		product.setId(1);
		product.setName("Birth");
		product.setDescription("BD");
		product.setUnitPrice("500");
		product.setImageUrl("assets/images/flowers/Birthday3.jpg");
		
	    Mockito.when(productRepository.save(product)).thenReturn(product);
	    System.out.println(productService.saveProduct(product));
	    System.out.println(product);
	    assertThat(productService.saveProduct(product)).isEqualTo(product);
	
	}
	
	@Test
	public void testGetAllProducts(){
		Products mockProduct = new Products();
		mockProduct.setId(1);;
		mockProduct.setName("Anniversary");
		mockProduct.setImageUrl("assets/images/flowers/Birthday2.jpg");
		mockProduct.setUnitPrice("500");
		

		Products mockProduct2 = new Products();
		mockProduct2.setId(1);;
		mockProduct2.setName("Birthday");
		mockProduct2.setImageUrl("assets/images/flowers/Birthday1.jpg");
		mockProduct2.setUnitPrice("600");
		
		List<Products> producttList = new ArrayList<>();
		producttList.add(mockProduct);
		producttList.add(mockProduct2);
		
		Mockito.when(productRepository.findAll()).thenReturn(producttList);
		assertThat(productService.getAllProducts()).isEqualTo(producttList);
	}
	
	 protected String mapToJson(Object obj) throws JsonProcessingException {
	      ObjectMapper objectMapper = new ObjectMapper();
	      return objectMapper.writeValueAsString(obj);
	   }
}
