package net.com.wipro.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.JsonParseException;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.com.wipro.model.Products;
import net.com.wipro.service.ProductService;

@RunWith(SpringRunner.class)
@WebMvcTest(value = ProductController.class, secure = false)
public class ProductControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private ProductService productService;
	
	@Test
	public void testAddProduct() throws Exception {
		
		Products mockProduct = new Products();
		mockProduct.setId(1);
		mockProduct.setName("Birth");
		mockProduct.setDescription("BD");
		mockProduct.setUnitPrice("500");
		mockProduct.setImageUrl("assets/images/flowers/Birthday3.jpg");
		
		String inputInJson = this.mapToJson(mockProduct);
		
        String URL = "/product/add";
		
		Mockito.when(productService.saveProduct(Mockito.any(Products.class))).thenReturn(mockProduct);
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post(URL)
				.accept(MediaType.APPLICATION_JSON).content(inputInJson)
				.contentType(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
		
		String outputInJson = response.getContentAsString();
		
		assertThat(outputInJson).isEqualTo(inputInJson);
		assertEquals(HttpStatus.OK.value(), response.getStatus());
	}
	
	@Test
	public void testGetProducts() throws Exception {
		Products mockProduct = new Products();
		mockProduct.setId(1);;
		mockProduct.setName("Anniversary");
		mockProduct.setImageUrl("assets/images/flowers/Birthday2.jpg");
		mockProduct.setUnitPrice("500");
		

		Products mockProduct2 = new Products();
		mockProduct2.setId(1);;
		mockProduct2.setName("Birthday");
		mockProduct2.setImageUrl("assets/images/flowers/Birthday1.jpg");
		mockProduct2.setUnitPrice("600");
		
		List<Products> producttList = new ArrayList<>();
		producttList.add(mockProduct);
		producttList.add(mockProduct2);
		
        Mockito.when(productService.getAllProducts()).thenReturn(producttList);
		
		String URI = "/product/getAll";
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
				URI).accept(
				MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		System.out.println("e"+result);
		String expectedJson = this.mapToJson(producttList);
		String outputInJson = result.getResponse().getContentAsString();
		System.out.println(outputInJson);
		assertThat(outputInJson).isEqualTo(expectedJson);
	}
	
	
	 protected String mapToJson(Object obj) throws JsonProcessingException {
	      ObjectMapper objectMapper = new ObjectMapper();
	      return objectMapper.writeValueAsString(obj);
	   }
	
	 protected <T> T mapFromJson(String json, Class<T> clazz)
		      throws JsonParseException, JsonMappingException, IOException {
		      
		      ObjectMapper objectMapper = new ObjectMapper();
		      return objectMapper.readValue(json, clazz);
		   }

}
